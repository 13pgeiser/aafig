#!/usr/bin/env python
#
# This file is part of aafigure. https://github.com/aafigure/aafigure
# (C) 2017 Chris Liechti <cliechti@gmx.net>
#
# SPDX-License-Identifier:    BSD-3-Clause

# command line stub for aafigure

from . import aafigure
aafigure.main()
